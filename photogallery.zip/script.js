$(document).ready(function () {
  let currentIndex = 0;
  const images = $(".gallery-img");

  // Open modal on image click
  $(".gallery-img").click(function () {
    currentIndex = images.index(this);
    updateModalImage();
    $("#imageModal").modal("show");
  });

  // Update modal image
  function updateModalImage() {
    let src = $(images[currentIndex]).attr("src");
    $("#modalImage").attr("src", src);
  }

  // Next image
  $("#nextBtn").click(function () {
    currentIndex = (currentIndex + 1) % images.length;
    updateModalImage();
  });

  // Previous image
  $("#prevBtn").click(function () {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    updateModalImage();
  });

  // Keyboard navigation
  $(document).keydown(function (e) {
    if ($("#imageModal").hasClass("show")) {
      if (e.key === "ArrowRight") {
        $("#nextBtn").click();
      } else if (e.key === "ArrowLeft") {
        $("#prevBtn").click();
      }
    }
  });
});
